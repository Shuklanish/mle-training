housing package
===============

Submodules
----------

housing.ingest\_data module
---------------------------

.. automodule:: housing.ingest_data
   :members:
   :undoc-members:
   :show-inheritance:

housing.logger module
---------------------

.. automodule:: housing.logger
   :members:
   :undoc-members:
   :show-inheritance:

housing.score module
--------------------

.. automodule:: housing.score
   :members:
   :undoc-members:
   :show-inheritance:

housing.train module
--------------------

.. automodule:: housing.train
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: housing
   :members:
   :undoc-members:
   :show-inheritance:
